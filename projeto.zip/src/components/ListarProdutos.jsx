export function ListarProdutos(props) {
  return (
    <ul>
      {props.produtos.map((produto) => (
        <li>
          <h2>{produto.nome}</h2>
        </li>
      ))}
    </ul>
  );
}
