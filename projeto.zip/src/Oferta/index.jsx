import { useState } from "react";
import { ListarProdutos } from "../components/ListarProdutos";

const ofertas = [
  {
    id: 0,
    nome: "",
    valor: 0,
    imagem: "",
    material: "",
    tamanho: "",
    peso: 0,
    itens: ["caixa", "saco de algodão"],
  },
  {
    id: 0,
    nome: "",
    valor: 0,
    imagem: "",
    material: "",
    tamanho: "",
    peso: 0,
    itens: ["caixa", "saco de algodão"],
  },
  {
    id: 0,
    nome: "",
    valor: 0,
    imagem: "",
    material: "",
    tamanho: "",
    peso: 0,
    itens: ["caixa", "saco de algodão"],
  },
  {
    id: 0,
    nome: "",
    valor: 0,
    imagem: "",
    material: "",
    tamanho: "",
    peso: 0,
    itens: ["caixa", "saco de algodão"],
  },
  {
    id: 0,
    nome: "",
    valor: 0,
    imagem: "",
    material: "",
    tamanho: "",
    peso: 0,
    itens: ["caixa", "saco de algodão"],
  },
  {
    id: 0,
    nome: "",
    valor: 0,
    imagem: "",
    material: "",
    tamanho: "",
    peso: 0,
    itens: ["caixa", "saco de algodão"],
  },
  {
    id: 0,
    nome: "",
    valor: 0,
    imagem: "",
    material: "",
    tamanho: "",
    peso: 0,
    itens: ["caixa", "saco de algodão"],
  },
  {
    id: 0,
    nome: "",
    valor: 0,
    imagem: "",
    material: "",
    tamanho: "",
    peso: 0,
    itens: ["caixa", "saco de algodão"],
  },
  {
    id: 0,
    nome: "",
    valor: 0,
    imagem: "",
    material: "",
    tamanho: "",
    peso: 0,
    itens: ["caixa", "saco de algodão"],
  },
  {
    id: 0,
    nome: "",
    valor: 0,
    imagem: "",
    material: "",
    tamanho: "",
    peso: 0,
    itens: ["caixa", "saco de algodão"],
  },
];

export default function Oferta() {
  const [listaOfertas, setListaOfertas] = useState(ofertas);

  return (
    <>
      <h1>Minha Oferta</h1>
      <ListarProdutos produtos={listaOfertas} />
    </>
  );
}
