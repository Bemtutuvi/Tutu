import Header from "../components/Header";
import { Carousel } from "react-responsive-carousel";
import "react-responsive-carousel/lib/styles/carousel.min.css";
import "../globals.css";
import { useState } from "react";
import { ListarProdutos } from "../components/ListarProdutos";

const destaques = [
  {
    id: 0,
    nome: "ASDASDASD",
    valor: 0,
    imagem: "",
    material: "",
    tamanho: "",
    peso: 0,
    itens: ["tsuba", "caixa", "saco de algodão"],
  },
  {
    id: 0,
    nome: "",
    valor: 0,
    imagem: "",
    material: "",
    tamanho: "",
    peso: 0,
    itens: ["tsuba", "caixa", "saco de algodão"],
  },
  {
    id: 0,
    nome: "asdasd",
    valor: 0,
    imagem: "",
    material: "",
    tamanho: "",
    peso: 0,
    itens: ["tsuba", "caixa", "saco de algodão"],
  },
  {
    id: 0,
    nome: "",
    valor: 0,
    imagem: "",
    material: "",
    tamanho: "",
    peso: 0,
    itens: ["tsuba", "caixa", "saco de algodão", "adesivos"],
  },
  {
    id: 0,
    nome: "",
    valor: 0,
    imagem: "",
    material: "",
    tamanho: "",
    peso: 0,
    itens: ["caixa", "saco de algodão"],
  },
];

export default function Home() {
  const [listaDestaque, setListaDestaque] = useState(destaques);

  return (
    <>
      <Header />
      <Carousel
        infiniteLoop
        useKeyboardArrows
        autoPlay
        showArrows={true}
        showStatus={false}
        showThumbs={false}
        dynamicHeight
      >
        <div>
          <img
            src="https://katana-japonais.com/cdn/shop/products/1_9e2bb6d7-328d-478d-bbf0-42ace18c2694.jpg?v=1667493823products/0p25vheceluolovfymlzaondbdu5ldpmzjvp_640x640.jpg?v=1661350192&webp=0"
            alt="Katana Hideyoshi Bainha Vermelha"
          />
        </div>
        <div>
          <img
            src="https://katana-univers.fr/wp-content/uploads/2023/08/Katana-Kogan-no-Ken.jpg"
            alt="Katana Ougon no Ken Dourada"
          />
        </div>
        <div>
          <img
            src="https://m.media-amazon.com/images/I/61p2L0hgE2L._AC_UF1000,1000_QL80_.jpg"
            alt="Katana Demon Slayer"
          />
        </div>
      </Carousel>
      <h1>Katanas do Sul</h1>
      <ListarProdutos produtos={listaDestaque} />
    </>
  );
}
