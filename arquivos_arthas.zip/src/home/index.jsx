import Header from "../components/Heater";
import { Carousel } from 'react-responsive-carousel';

export default function Home(){
    return(
        <>
        <Header/>
        
        <p>Minha Home</p>
        </>
    );
}