export default function Oferta(){
    return(
        <h1>Minha Oferta</h1>
    );
}
import { Carousel } from 'react-responsive-carousel';